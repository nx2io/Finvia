import mongoose from 'mongoose';
import BinanceDepositVerification from '../models/binance-deposit-verification.model.js';
import Wallet from '../models/wallet.model.js';
import Transaction from '../models/transaction.model.js';
import User from '../models/user.model.js';
import { clearCache } from "../utils/cache.js";

// Helper function for atomic balance updates (Consider moving to a shared utility)
const updateBalance = async (walletId, amount, subWalletId = null, session = null) => {
    const update = {};
    const filter = { _id: walletId };

    if (subWalletId) {
        filter['subWallets._id'] = subWalletId;
        if (amount < 0) filter['subWallets.$.balance'] = { $gte: Math.abs(amount) };
        update['$inc'] = { 'subWallets.$.balance': amount };
    } else {
        if (amount < 0) filter.mainBalance = { $gte: Math.abs(amount) };
        update['$inc'] = { mainBalance: amount };
    }

    const options = { new: true, session };
    const updatedWallet = await Wallet.findOneAndUpdate(filter, update, options);

    if (!updatedWallet) {
        throw new Error('Insufficient funds or wallet/sub-wallet not found.');
    }
    return updatedWallet;
};

/**
 * @description Get deposit instructions (e.g., Binance address and memo)
 * @route GET /v1/deposit/instructions
 * @access Private
 */
export const getDepositInstructions = async (req, res, next) => {
    const userId = req.userId;
    try {
        // Fetch deposit address and memo from environment variables or a secure config
        // IMPORTANT: These should be specific to YOUR application's Binance account.
        // Use a unique memo/tag per user if possible for easier tracking, though requires more setup.
        const depositAddress = process.env.BINANCE_USDT_DEPOSIT_ADDRESS;
        const depositMemo = process.env.BINANCE_USDT_DEPOSIT_MEMO; // Optional, depends on network/setup
        const depositNetwork = process.env.BINANCE_USDT_DEPOSIT_NETWORK || 'TRC20'; // Example network

        if (!depositAddress) {
            console.error("CRITICAL: Binance deposit address not configured in environment variables.");
            return res.status(500).json({ success: false, message: 'Deposit service is currently unavailable. Please contact support.' });
        }

        // Optionally, generate a unique reference for the user to include
        const uniqueReference = `DEP-${userId.slice(-4)}-${Date.now().toString().slice(-5)}`;

        res.status(200).json({
            success: true,
            data: {
                network: depositNetwork,
                address: depositAddress,
                memo: depositMemo, // Include if applicable
                reference: uniqueReference, // Include if generated
                instructions: `Please deposit USDT (${depositNetwork}) to the address above. ${depositMemo ? 'Ensure you include the memo: ' + depositMemo + '.' : ''} After depositing, submit the transaction details and screenshot for verification.`
            }
        });
    } catch (error) {
        console.error("Get Deposit Instructions Error:", error);
        next(error);
    }
};

/**
 * @description Submit deposit details for manual verification (User uploads TxID, amount, screenshot)
 * @route POST /v1/deposit/submit-verification
 * @access Private
 */
export const submitDepositVerification = async (req, res, next) => {
    // SECURITY: Add input validation middleware
    // SECURITY: Handle file uploads securely (screenshotUrl)
    const userId = req.userId;
    const { transactionId, amount, currency, screenshotUrl } = req.body;

    if (!transactionId || !amount || amount <= 0 || !currency || !screenshotUrl) {
        return res.status(400).json({ success: false, message: 'Transaction ID, amount, currency, and screenshot URL are required' });
    }

    if (currency !== 'USDT') {
        // Currently only supporting USDT based on requirements
        return res.status(400).json({ success: false, message: 'Only USDT deposits are currently supported' });
    }

    try {
        // Check for duplicate Transaction ID submission by this user?
        const existingVerification = await BinanceDepositVerification.findOne({ userId, transactionId });
        if (existingVerification) {
            return res.status(409).json({ success: false, message: `Verification for Transaction ID ${transactionId} already submitted.` });
        }

        const verification = new BinanceDepositVerification({
            userId,
            transactionId,
            amount,
            currency, // Should be USDT
            screenshotUrl,
            status: 'pending', // Initial status for admin review
            submittedAt: new Date(),
        });

        await verification.save();

        // Create a placeholder transaction record for the user's history
        const user = await User.findById(userId).populate('mainWalletId');
        if (user && user.mainWalletId) {
            const depositTx = new Transaction({
                userId: userId,
                walletId: user.mainWalletId._id,
                type: 'DEPOSIT',
                status: 'pending_verification',
                amount: amount,
                currency: currency,
                fee: 0, // Assume no fee for deposit itself
                netAmount: amount,
                description: `Deposit verification submitted (TxID: ${transactionId.slice(0, 8)}...)`,
                externalTransactionId: transactionId,
                relatedVerificationId: verification._id,
                initiatedAt: new Date(),
            });
            await depositTx.save();
        } else {
            console.warn(`Could not create placeholder deposit transaction for user ${userId} - User or Wallet not found.`);
        }

        // Notify admin system? (Out of scope)

        res.status(201).json({
            success: true,
            message: 'Deposit details submitted successfully. Please allow time for verification.',
            data: verification
        });

    } catch (error) {
        console.error("Submit Deposit Verification Error:", error);
        next(error);
    }
};

/**
 * @description Get status of submitted deposit verifications for the user
 * @route GET /v1/deposit/verification-status
 * @access Private
 */
export const getDepositVerificationStatus = async (req, res, next) => {
    const userId = req.userId;
    const { limit = 10, page = 1 } = req.query;

    const query = { userId: userId };
    const options = {
        limit: parseInt(limit),
        skip: (parseInt(page) - 1) * parseInt(limit),
        sort: { submittedAt: -1 }
    };

    try {
        const verifications = await BinanceDepositVerification.find(query, null, options)
            .select('-__v -screenshotUrl'); // Exclude sensitive/large fields
        const totalVerifications = await BinanceDepositVerification.countDocuments(query);

        res.status(200).json({
            success: true,
            data: verifications,
            pagination: {
                currentPage: parseInt(page),
                totalPages: Math.ceil(totalVerifications / parseInt(limit)),
                totalVerifications
            }
        });
    } catch (error) {
        console.error("Get Deposit Verification Status Error:", error);
        next(error);
    }
};

// --- Admin Actions (Should be in Admin Controller with Admin Auth Middleware) ---

/**
 * @description Manually approve a pending deposit verification and credit user wallet
 * @route PUT /v1/admin/deposits/:verificationId/approve
 * @access Restricted (Admin)
 */
export const approveDeposit = async (req, res, next) => {
    // SECURITY: Add Admin authorization middleware
    const verificationId = req.params.verificationId;
    const adminUserId = req.userId; // Assuming admin user ID is available

    if (!verificationId) {
        return res.status(400).json({ success: false, message: 'Verification ID is required' });
    }

    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        // 1. Find the pending verification record
        const verification = await BinanceDepositVerification.findById(verificationId).session(session);
        if (!verification) {
            throw new Error('Deposit verification record not found.');
        }
        if (verification.status !== 'pending') {
            throw new Error(`Verification status is already '${verification.status}'. Cannot approve.`);
        }

        // 2. Find the user and their wallet
        const user = await User.findById(verification.userId).populate('mainWalletId').session(session);
        if (!user || !user.mainWalletId) {
            throw new Error('User or user wallet not found.');
        }
        const wallet = user.mainWalletId;

        // 3. Validate currency (Wallet should be USD, deposit is USDT - assume 1:1 for now)
        if (wallet.primaryCurrency !== 'USD' || verification.currency !== 'USDT') {
            // This needs clarification - are we converting USDT to USD?
            // For now, assume 1 USDT = 1 USD and wallet is USD.
            console.warn(`Currency mismatch: Wallet is ${wallet.primaryCurrency}, Deposit is ${verification.currency}. Assuming 1:1 conversion.`);
            // throw new Error(`Currency mismatch: Wallet is ${wallet.primaryCurrency}, Deposit is ${verification.currency}.`);
        }
        const creditAmount = verification.amount; // Amount in USD (assuming 1:1)

        // 4. Credit the user's main wallet balance
        await updateBalance(wallet._id, creditAmount, null, session);

        // 5. Update the verification record status
        verification.status = 'approved';
        verification.processedAt = new Date();
        verification.processedBy = adminUserId;
        await verification.save({ session });

        // 6. Update the placeholder transaction record
        const updatedTx = await Transaction.findOneAndUpdate(
            { relatedVerificationId: verification._id, status: 'pending_verification' },
            { $set: { status: 'completed', completedAt: new Date(), netAmount: creditAmount /* Update net amount if needed */ } },
            { new: true, session: session }
        );

        if (!updatedTx) {
            console.warn(`Placeholder transaction not found or already processed for verification ${verificationId}`);
            // Decide if this should cause transaction rollback - maybe not, main action is done.
        }

        // 7. Commit transaction
        await session.commitTransaction();
        session.endSession();

        // 8. Clear cache
        await clearCache(`walletDetails:${verification.userId}`);
        // Clear user's transaction history cache

        // Notify user? (Out of scope)

        res.status(200).json({ success: true, message: 'Deposit approved and wallet credited successfully.', data: verification });

    } catch (error) {
        if (session.inTransaction()) {
            await session.abortTransaction();
        }
        session.endSession();
        console.error("Approve Deposit Error:", error);
        if (error.message.includes('not found') || error.message.includes('status')) {
            return res.status(400).json({ success: false, message: error.message });
        }
        next(error);
    }
};

/**
 * @description Manually reject a pending deposit verification
 * @route PUT /v1/admin/deposits/:verificationId/reject
 * @access Restricted (Admin)
 */
export const rejectDeposit = async (req, res, next) => {
    // SECURITY: Add Admin authorization middleware
    const verificationId = req.params.verificationId;
    const adminUserId = req.userId;
    const { reason } = req.body;

    if (!verificationId) {
        return res.status(400).json({ success: false, message: 'Verification ID is required' });
    }
    if (!reason) {
        return res.status(400).json({ success: false, message: 'Rejection reason is required' });
    }

    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        // 1. Find the pending verification record
        const verification = await BinanceDepositVerification.findById(verificationId).session(session);
        if (!verification) {
            throw new Error('Deposit verification record not found.');
        }
        if (verification.status !== 'pending') {
            throw new Error(`Verification status is already '${verification.status}'. Cannot reject.`);
        }

        // 2. Update the verification record status
        verification.status = 'rejected';
        verification.rejectionReason = reason;
        verification.processedAt = new Date();
        verification.processedBy = adminUserId;
        await verification.save({ session });

        // 3. Update the placeholder transaction record
        const updatedTx = await Transaction.findOneAndUpdate(
            { relatedVerificationId: verification._id, status: 'pending_verification' },
            { $set: { status: 'rejected', completedAt: new Date() } },
            { new: true, session: session }
        );

        if (!updatedTx) {
            console.warn(`Placeholder transaction not found or already processed for verification ${verificationId}`);
        }

        // 4. Commit transaction
        await session.commitTransaction();
        session.endSession();

        // Notify user? (Out of scope)

        res.status(200).json({ success: true, message: 'Deposit verification rejected.', data: verification });

    } catch (error) {
        if (session.inTransaction()) {
            await session.abortTransaction();
        }
        session.endSession();
        console.error("Reject Deposit Error:", error);
        if (error.message.includes('not found') || error.message.includes('status')) {
            return res.status(400).json({ success: false, message: error.message });
        }
        next(error);
    }
};

