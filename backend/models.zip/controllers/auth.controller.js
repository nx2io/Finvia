import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { v4 as uuidv4 } from 'uuid'; // Import UUID for wallet number generation

import User from '../models/user.model.js';
import Wallet from '../models/wallet.model.js'; // Import Wallet model
import SubscriptionPlan from '../models/subscription-plan.model.js'; // Import SubscriptionPlan model
import UserSubscription from '../models/user-subscription.model.js'; // Import UserSubscription model

import { generateTokenAndSetCookie } from "../utils/generateTokenAndSetCookie.js";
import { sendVerificationEmail, sendWelcomeEmail, sendPasswordResetEmail, sendResetSuccessEmail } from "../utils/emails.js";
import { getOrSetCache } from "../utils/cache.js";

// Helper function to generate a unique wallet number (example implementation)
const generateWalletNumber = () => {
  // Generate a UUID, remove hyphens, and take a portion for uniqueness
  // This is just an example; a more robust method might be needed for production
  const uuid = uuidv4().replace(/-/g, '');
  // Combine timestamp and random part of UUID for better distribution
  return `W${Date.now().toString().slice(-6)}${uuid.slice(0, 6)}`.toUpperCase();
};

export const signUp = async (req, res, next) => {
  // SECURITY: Add input validation middleware (e.g., using express-validator) before this controller
  const { fullName, email, password, username, phone, nationality, birthDate } = req.body; // Added new fields based on revised user model

  // Basic validation (more robust validation should be in middleware)
  if (!fullName || !email || !password || !username || !phone || !nationality || !birthDate) {
    return res.status(400).json({ success: false, message: 'Missing required fields' });
  }
  // Add validation for phone object structure, nationality, birthDate format etc.

  // Start MongoDB session for transaction (Requires Replica Set)
  // const session = await mongoose.startSession();
  // session.startTransaction();

  try {
    const existingUser = await User.findOne({ $or: [{ email }, { username }] }); //.session(session);
    if (existingUser) {
      // await session.abortTransaction();
      // session.endSession();
      const field = existingUser.email === email ? 'Email' : 'Username';
      return res.status(409).json({ success: false, message: `${field} already exists` });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    // Use crypto for verification token for better security than Math.random
    const verificationToken = crypto.randomBytes(3).toString('hex').toUpperCase(); // 6-char hex token

    // 1. Create User
    const user = new User({
      fullName,
      email,
      username,
      password: hashedPassword,
      phone, // Assuming phone is { countryCode: '...', number: '...' }
      nationality,
      birthDate,
      // avatarUrl: default is set in model
      status: 'pending_verification', // Initial status
      isEmailVerified: false,
      emailVerificationToken: verificationToken,
      emailVerificationExpires: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
      // kyc, twoFactorAuth will be handled separately
    });
    await user.save(); // { session } - Add session if using transactions

    // 2. Create Wallet
    const walletNumber = generateWalletNumber();
    const wallet = new Wallet({
      userId: user._id,
      walletNumber: walletNumber,
      primaryCurrency: 'USD', // Default currency
      mainBalance: 0,
      // status: default is 'active'
    });
    await wallet.save(); // { session }

    // 3. Assign Free Subscription Plan
    const freePlan = await SubscriptionPlan.findOne({ planId: 'FREE' }); //.session(session);
    let userSubscription;
    if (freePlan) {
      userSubscription = new UserSubscription({
        userId: user._id,
        planId: freePlan._id,
        planDetails: {
          planIdString: freePlan.planId,
          name: freePlan.name,
          price: freePlan.price,
          currency: freePlan.currency,
          billingCycle: freePlan.billingCycle,
        },
        status: 'active', // Free plans are active immediately
        startDate: new Date(),
        // endDate is not needed for free plans
        autoRenew: false,
      });
      await userSubscription.save(); // { session }
    } else {
      console.error("CRITICAL: Free subscription plan not found!");
      // Handle this case - maybe prevent user creation or log critical error
      // For now, proceed without subscription assignment but log error
    }

    // 4. Update User with Wallet ID and Subscription Info
    user.mainWalletId = wallet._id;
    if (userSubscription) {
      user.subscription = {
        planId: freePlan._id,
        status: userSubscription.status,
        // expiresAt: userSubscription.endDate // Not needed for free
      };
    }
    await user.save(); // { session }

    // Commit transaction if using sessions
    // await session.commitTransaction();
    // session.endSession();

    // 5. Send Verification Email & Generate Auth Token
    try {
      await sendVerificationEmail(user.email, verificationToken);
    } catch (emailError) {
      console.error(`Failed to send verification email to ${user.email}:`, emailError);
      // Decide if this should prevent successful response - maybe not, user can resend
    }

    const token = generateTokenAndSetCookie(res, user._id);

    // Exclude sensitive fields from the response
    const userResponse = user.toObject();
    delete userResponse.password;
    delete userResponse.emailVerificationToken;
    delete userResponse.emailVerificationExpires;
    // ... remove other sensitive fields as needed

    res.status(201).json({
      success: true,
      message: 'User created successfully. Please check your email to verify your account.',
      data: {
        token,
        user: userResponse,
        wallet: wallet.toObject(), // Send basic wallet info
        subscription: userSubscription ? userSubscription.toObject() : null // Send subscription info
      }
    });

  } catch (error) {
    // Abort transaction if using sessions and an error occurred
    // if (session && session.inTransaction()) {
    //   await session.abortTransaction();
    // }
    // if (session) {
    //   session.endSession();
    // }
    console.error("Signup Error:", error); // Log the detailed error
    next(error); // Pass error to the error handling middleware
  }
};

export const signIn = async (req, res, next) => {
  // SECURITY: Add input validation middleware
  const { email, password } = req.body;

  if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required' });
  }

  try {
    // Fetch user and select password explicitly as it's excluded by default
    const user = await User.findOne({ $or: [{ email }, { username: email }] }).select('+password');

    if (!user) {
      return res.status(404).json({ success: false, message: 'Invalid credentials' }); // Generic message for security
    }

    // Handle users created via Google/OAuth who haven't set a password
    if (!user.password) {
      return res.status(401).json({ success: false, message: "Authentication method not supported. Try signing in with Google or reset password." });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' }); // Generic message
    }

    // Check user status
    if (!user.isEmailVerified) {
      // Allow login but inform user? Or block? Let's block for now.
      return res.status(403).json({ success: false, message: "Please verify your email before signing in." });
    }
    if (user.status === 'suspended' || user.status === 'banned') {
      return res.status(403).json({ success: false, message: `Your account is ${user.status}. Please contact support.` });
    }
    if (user.status === 'closed') {
        return res.status(403).json({ success: false, message: `Your account is closed.` });
    }
    // if (user.status === 'pending_verification') {
    //     // This might happen if email verification is pending
    //     return res.status(403).json({ success: false, message: "Please verify your email before signing in." });
    // }

    // Update last login timestamp and potentially IP address log
    user.lastLoginTimestamp = new Date();
    // Add IP logging here if needed
    await user.save();

    const token = generateTokenAndSetCookie(res, user._id);

    // Exclude sensitive fields from the response
    const userResponse = user.toObject();
    delete userResponse.password;
    // ... remove other sensitive fields

    res.status(200).json({
      success: true,
      message: 'User signed in successfully',
      data: {
        token,
        user: userResponse,
      }
    });
  } catch (error) {
    console.error("Signin Error:", error);
    next(error);
  }
};

export const signOut = async (req, res, next) => {
  try {
    res.clearCookie("token"); // Use the correct cookie name used in generateTokenAndSetCookie
    res.status(200).json({ success: true, message: 'User signed out successfully' });
  } catch (error) {
    next(error);
  }
};

export const googleCallback = async (req, res, next) => {
  // const session = await mongoose.startSession();
  // session.startTransaction();
  try {
    console.log("Google User Data:", req.user); // Log data for debugging

    const { id: googleId, displayName, email, photos } = req.user || {};

    if (!email) {
      // await session.abortTransaction();
      // session.endSession();
      return res.status(400).json({ success: false, error: "No email provided by Google" });
    }

    let user = await User.findOne({ email }); //.session(session);

    if (!user) {
      // New user via Google
      let baseUsername = email.split("@")[0].replace(/[^a-zA-Z0-9_]/g, ''); // Sanitize username
      let username = baseUsername;
      let counter = 1;
      while (await User.findOne({ username })) { //.session(session)) {
        username = `${baseUsername}${counter}`;
        counter++;
      }

      // 1. Create User
      user = new User({
        googleId, // Store Google ID
        fullName: displayName,
        email: email,
        username: username,
        avatarUrl: photos?.[0]?.value,
        // Password is not set for Google users initially
        status: 'active', // Assume active as email is verified by Google
        isEmailVerified: true,
        // Fill required fields like phone, nationality, birthDate later via profile completion step
        // For now, we might need to make them non-required or handle this flow
        // Let's assume they are NOT strictly required for initial Google signup based on revised model
        // phone: { countryCode: '?', number: '?' }, // Placeholder or make optional
        // nationality: '?', // Placeholder or make optional
        // birthDate: new Date(0), // Placeholder or make optional
      });
      await user.save(); // { session }

      // 2. Create Wallet
      const walletNumber = generateWalletNumber();
      const wallet = new Wallet({
        userId: user._id,
        walletNumber: walletNumber,
        primaryCurrency: 'USD',
        mainBalance: 0,
      });
      await wallet.save(); // { session }

      // 3. Assign Free Subscription
      const freePlan = await SubscriptionPlan.findOne({ planId: 'FREE' }); //.session(session);
      let userSubscription;
      if (freePlan) {
        userSubscription = new UserSubscription({
          userId: user._id,
          planId: freePlan._id,
          planDetails: { /* ... copy plan details ... */ },
          status: 'active',
          startDate: new Date(),
        });
        await userSubscription.save(); // { session }
      } else {
        console.error("CRITICAL: Free subscription plan not found for Google signup!");
      }

      // 4. Update User with Wallet ID and Subscription
      user.mainWalletId = wallet._id;
      if (userSubscription) {
        user.subscription = {
          planId: freePlan._id,
          status: userSubscription.status,
        };
      }
      await user.save(); // { session }

      // Send Welcome Email
      try {
        await sendWelcomeEmail(user.email, user.fullName);
      } catch (emailError) {
        console.error(`Failed to send welcome email to ${user.email}:`, emailError);
      }

    } else {
      // Existing user logging in via Google
      // Update avatar or name if changed?
      user.lastLoginTimestamp = new Date();
      // Add IP logging
      await user.save(); // { session }
    }

    // Commit transaction
    // await session.commitTransaction();
    // session.endSession();

    const token = generateTokenAndSetCookie(res, user._id);

    // Exclude sensitive fields
    const userResponse = user.toObject();
    delete userResponse.password;
    // ... remove others

    // Redirect user or send response
    // Option 1: Redirect to frontend dashboard
    // res.redirect(`${process.env.CLIENT_URL}/dashboard?token=${token}`); // Pass token if needed

    // Option 2: Send JSON response (useful for SPAs)
    res.status(200).json({
      success: true,
      message: "User signed in successfully via Google",
      data: {
        token,
        user: userResponse,
      },
    });

  } catch (error) {
    // Abort transaction
    // if (session && session.inTransaction()) { await session.abortTransaction(); }
    // if (session) { session.endSession(); }
    console.error("Google Callback Error:", error);
    next(error);
  }
};

export const verifyEmail = async (req, res, next) => {
  // SECURITY: Add input validation middleware
  const { code } = req.body;
  if (!code) {
      return res.status(400).json({ success: false, message: "Verification code is required" });
  }

  // const session = await mongoose.startSession();
  // session.startTransaction();
  try {
    const user = await User.findOne({
      emailVerificationToken: code,
      emailVerificationExpires: { $gt: Date.now() },
    }); //.session(session);

    if (!user) {
      // await session.abortTransaction();
      // session.endSession();
      return res.status(400).json({ success: false, message: "Invalid or expired verification code" });
    }

    if (user.isEmailVerified) {
        // await session.abortTransaction();
        // session.endSession();
        return res.status(400).json({ success: false, message: "Email is already verified" });
    }

    user.isEmailVerified = true;
    user.status = 'active'; // Update status to active upon verification
    user.emailVerificationToken = undefined;
    user.emailVerificationExpires = undefined;
    await user.save(); // { session }

    // Commit transaction
    // await session.commitTransaction();
    // session.endSession();

    // Send Welcome Email (optional, maybe sent at signup)
    // await sendWelcomeEmail(user.email, user.fullName);

    const token = generateTokenAndSetCookie(res, user._id);

    const userResponse = user.toObject();
    delete userResponse.password;
    // ... remove others

    res.status(200).json({
      success: true,
      message: "Email verified successfully",
      data: {
          token: token,
          user: userResponse,
      }
    });
  } catch (error) {
    // Abort transaction
    // if (session && session.inTransaction()) { await session.abortTransaction(); }
    // if (session) { session.endSession(); }
    console.error("Verify Email Error:", error);
    next(error);
  }
};

export const resendVerificationEmail = async (req, res, next) => {
  // SECURITY: Add input validation middleware
  const { email } = req.body;
  if (!email) {
      return res.status(400).json({ success: false, message: "Email is required" });
  }

  try {
    const user = await User.findOne({ email: email });

    if (!user) {
      // Return generic message to prevent user enumeration
      return res.status(200).json({ success: true, message: "If an account with that email exists, a new verification code has been sent." });
    }

    if (user.isEmailVerified) {
      return res.status(400).json({ success: false, message: "Email is already verified" });
    }

    // SECURITY: Implement rate limiting middleware for this endpoint
    const cooldownTime = 60 * 1000; // 1 minute
    const now = Date.now();
    // Check if verificationTokenSentAt exists and is recent
    // This field needs to be added to the user model if not present
    if (user.verificationTokenSentAt && now - user.verificationTokenSentAt < cooldownTime) {
      const remainingTime = Math.ceil((cooldownTime - (now - user.verificationTokenSentAt)) / 1000);
      return res.status(429).json({
        success: false,
        message: `Please wait ${remainingTime} seconds before requesting a new code.`,
      });
    }

    const verificationToken = crypto.randomBytes(3).toString('hex').toUpperCase();
    user.emailVerificationToken = verificationToken;
    // user.verificationTokenSentAt = now; // Update timestamp
    user.emailVerificationExpires = Date.now() + 1 * 60 * 60 * 1000; // 1 hour

    await user.save();

    try {
        await sendVerificationEmail(user.email, verificationToken);
    } catch (emailError) {
        console.error(`Failed to resend verification email to ${user.email}:`, emailError);
        // Don't expose email failure to user, but log it
        return res.status(500).json({ success: false, message: "Failed to send verification email. Please try again later." });
    }

    res.status(200).json({ success: true, message: "If an account with that email exists, a new verification code has been sent." });
  } catch (error) {
    console.error("Resend Verification Error:", error);
    next(error);
  }
}

export const forgotPassword = async (req, res, next) => {
  // SECURITY: Add input validation middleware
  const { email } = req.body;
  if (!email) {
      return res.status(400).json({ success: false, message: "Email is required" });
  }

  try {
    const user = await User.findOne({ email: email });

    if (!user) {
      // SECURITY: Return success to prevent user enumeration
      return res.status(200).json({ success: true, message: "If an account with that email exists, a password reset link has been sent." });
    }

    // SECURITY: Implement rate limiting middleware

    const resetToken = crypto.randomBytes(32).toString("hex");
    // Hash the token before storing it for comparison (like password reset best practices)
    const hashedResetToken = crypto.createHash('sha256').update(resetToken).digest('hex');

    user.passwordResetToken = hashedResetToken;
    user.passwordResetExpires = Date.now() + 1 * 60 * 60 * 1000; // 1 hour

    await user.save();

    // Send email with the *unhashed* token
    const resetUrl = `${process.env.CLIENT_URL}/auth/reset-password/${resetToken}`;
    try {
        await sendPasswordResetEmail(user.email, resetUrl);
    } catch (emailError) {
        console.error(`Failed to send password reset email to ${user.email}:`, emailError);
        return res.status(500).json({ success: false, message: "Failed to send password reset email. Please try again later." });
    }

    res.status(200).json({ success: true, message: "If an account with that email exists, a password reset link has been sent." });
  } catch (error) {
    console.error("Forgot Password Error:", error);
    next(error);
  }
};

export const resetPassword = async (req, res, next) => {
  // SECURITY: Add input validation middleware (for password strength)
  const { token } = req.params;
  const { password } = req.body;

  if (!password || password.length < 8) { // Basic validation
      return res.status(400).json({ success: false, message: "Password must be at least 8 characters long" });
  }

  try {
    // Hash the token from the URL to compare with the stored hash
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

    const user = await User.findOne({
      passwordResetToken: hashedToken,
      passwordResetExpires: { $gt: Date.now() },
    });

    if (!user) {
      return res.status(400).json({ success: false, message: "Password reset link is invalid or has expired." });
    }

    // Update password
    const hashedPassword = await bcrypt.hash(password, 10);

    user.password = hashedPassword;
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    // SECURITY: Force logout of other sessions if possible
    await user.save();

    try {
        await sendResetSuccessEmail(user.email);
    } catch (emailError) {
        console.error(`Failed to send password reset success email to ${user.email}:`, emailError);
        // Continue even if email fails
    }

    res.status(200).json({ success: true, message: "Password has been reset successfully. You can now sign in." });
  } catch (error) {
    console.error("Reset Password Error:", error);
    next(error);
  }
};

// --- User Management (Potentially move to User Controller or Admin Controller) ---

// Middleware to check if the requesting user is the owner or an admin
// Example: const checkUserOrAdmin = (req, res, next) => { ... }

export const checkAuth = async (req, res, next) => {
  // This endpoint relies on the authorize middleware setting req.userId
  try {
    // Use cache if appropriate
    const user = await getOrSetCache(`user:${req.userId}`, async () => {
        return await User.findById(req.userId).select("-password -__v"); // Exclude fields
    }, 60); // Cache for 60 seconds

    if (!user) {
      // This shouldn't happen if authorize middleware works correctly
      return res.status(404).json({ success: false, message: "User not found" });
    }

    res.status(200).json({ success: true, user });
  } catch (error) {
    console.error("Check Auth Error:", error);
    next(error);
  }
};

// --- Admin Specific Actions (Should be in Admin Controller with Admin Auth Middleware) ---

export const bannedUser = async (req, res, next) => {
  // Requires authorizeAdmin middleware
  const userId = req.params.id;
  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    // Prevent banning self?
    // Prevent banning other admins?
    user.status = user.status === 'banned' ? 'active' : 'banned'; // Toggle ban status
    user.banReason = user.status === 'banned' ? (req.body.reason || 'No reason provided') : undefined;
    await user.save();
    // SECURITY: Invalidate user's sessions/tokens
    res.status(200).json({ success: true, message: `User status set to ${user.status}`, user: { _id: user._id, status: user.status } });
  } catch (error) {
    console.error("Ban/Unban User Error:", error);
    next(error);
  }
};

// Deprecated: Combined into bannedUser toggle
// export const unbannedUser = async (req, res, next) => { ... };

export const getUserById = async (req, res, next) => {
  // Requires authorization (admin or maybe specific permissions)
  const userId = req.params.id;
  try {
    const user = await getOrSetCache(`user:${userId}`, async () => {
      return await User.findById(userId).select("-password -__v");
    }, 60);

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }
    res.status(200).json({ success: true, user });
  } catch (error) {
    console.error("Get User By ID Error:", error);
    next(error);
  }
};

export const getUserByEmailOrUsername = async (req, res, next) => {
    // Requires authorization
    const identifier = req.params.identifier; // Can be email or username
    try {
        const user = await getOrSetCache(`user:${identifier}`, async () => {
            return await User.findOne({ $or: [{ email: identifier }, { username: identifier }] }).select("-password -__v");
        }, 60);

        if (!user) {
            return res.status(404).json({ success: false, message: "User not found" });
        }
        res.status(200).json({ success: true, user });
    } catch (error) {
        console.error("Get User By Identifier Error:", error);
        next(error);
    }
};

export const deleteUser = async (req, res, next) => {
  // Requires authorizeAdmin middleware
  const userId = req.params.id;
  // const session = await mongoose.startSession();
  // session.startTransaction();
  try {
    const user = await User.findById(userId); //.session(session);
    if (!user) {
      // await session.abortTransaction();
      // session.endSession();
      return res.status(404).json({ success: false, message: "User not found" });
    }

    // Perform cleanup: Delete related wallet, subscriptions, etc.
    // await Wallet.deleteOne({ userId: userId }); // { session }
    // await UserSubscription.deleteMany({ userId: userId }); // { session }
    // ... other related data

    await User.findByIdAndDelete(userId); // { session }

    // await session.commitTransaction();
    // session.endSession();

    // SECURITY: Invalidate sessions/tokens
    // Clear cache
    // await redisClient.del(`user:${userId}`);

    res.status(200).json({ success: true, message: "User deleted successfully" });
  } catch (error) {
    // Abort transaction
    // if (session && session.inTransaction()) { await session.abortTransaction(); }
    // if (session) { session.endSession(); }
    console.error("Delete User Error:", error);
    next(error);
  }
};

// updateUser is potentially too broad, consider more specific endpoints in user.controller.js
// export const updateUser = async (req, res, next) => { ... };

