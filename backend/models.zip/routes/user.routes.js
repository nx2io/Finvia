import { Router } from 'express';

// Import controllers
import {
    getMyProfile,
    updateMyProfile,
    submitKyc,
    getKycStatus,
    addBankAccount,
    listBankAccounts,
    deleteBankAccount,
    setDefaultBankAccount,
    getTwoFactorStatus,
    initiateEnableTwoFactor,
    verifyEnableTwoFactor,
    disableTwoFactor,
    searchUsers,
    // Admin functions (moved to admin.routes.js)
    // getUserById,
    // listAllUsers
} from '../controllers/user.controller.js';

// Import middleware
import { authorize } from '../middlewares/auth.middleware.js'; // General authorization
// import { validateUpdateProfile, validateSubmitKyc, ... } from '../middlewares/validation.middleware.js'; // Placeholder for validation

const userRouter = Router();

// All routes below require authentication
userRouter.use(authorize);

// --- Profile Management ---
// GET /v1/users/profile/me
userRouter.get('/profile/me', getMyProfile);

// PUT /v1/users/profile/me
// Add validation middleware: validateUpdateProfile
userRouter.put('/profile/me', updateMyProfile);

// --- KYC Management ---
// POST /v1/users/kyc/submit
// Add validation middleware: validateSubmitKyc
// Add file upload middleware if handling uploads directly
userRouter.post('/kyc/submit', submitKyc);

// GET /v1/users/kyc/status
userRouter.get('/kyc/status', getKycStatus);

// --- Bank Account Management ---
// POST /v1/users/bank-accounts
// Add validation middleware: validateAddBankAccount
userRouter.post('/bank-accounts', addBankAccount);

// GET /v1/users/bank-accounts
userRouter.get('/bank-accounts', listBankAccounts);

// DELETE /v1/users/bank-accounts/:accountId
userRouter.delete('/bank-accounts/:accountId', deleteBankAccount);

// PUT /v1/users/bank-accounts/:accountId/default
userRouter.put('/bank-accounts/:accountId/default', setDefaultBankAccount);

// --- 2FA Management ---
// GET /v1/users/2fa/status
userRouter.get('/2fa/status', getTwoFactorStatus);

// POST /v1/users/2fa/enable/initiate
userRouter.post('/2fa/enable/initiate', initiateEnableTwoFactor);

// POST /v1/users/2fa/enable/verify
// Add validation middleware: validateVerify2FA
userRouter.post('/2fa/enable/verify', verifyEnableTwoFactor);

// POST /v1/users/2fa/disable
// Add validation middleware: validateDisable2FA (e.g., require password)
userRouter.post('/2fa/disable', disableTwoFactor);

// --- User Search ---
// GET /v1/users/search?q=<query>
userRouter.get('/search', searchUsers);

// --- Admin Routes (Moved to admin.routes.js) ---
// userRouter.get('/', authorizeAdmin, listAllUsers);
// userRouter.get('/:id', authorizeAdmin, getUserById);

export default userRouter;

