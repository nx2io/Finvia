import { Router } from 'express';
import passport from "passport";

// Import controllers
import {
    signUp,
    signIn,
    signOut,
    googleCallback,
    verifyEmail,
    resendVerificationEmail,
    forgotPassword,
    resetPassword,
    checkAuth // Keep checkAuth here for session verification
} from '../controllers/auth.controller.js';

// Import middleware
import { authorize } from '../middlewares/auth.middleware.js'; // General authorization
// import { authorizeAdmin } from '../middlewares/auth.middleware.js'; // Admin authorization (routes moved)
// import errorMiddleware from '../middlewares/error.middleware.js'; // Apply globally or specifically
// import { validateSignUp, validateSignIn, ... } from '../middlewares/validation.middleware.js'; // Placeholder for validation

const authRouter = Router();

// --- Public Routes ---

// POST /v1/auth/signup
// Add validation middleware: validateSignUp
authRouter.post('/signup', signUp);

// POST /v1/auth/signin
// Add validation middleware: validateSignIn
authRouter.post('/signin', signIn);

// POST /v1/auth/signout
authRouter.post('/signout', signOut); // No auth needed, clears cookie

// GET /v1/auth/google (Initiate Google OAuth)
authRouter.get("/google", passport.authenticate("google", { scope: ["profile", "email"] }));

// GET /v1/auth/google/callback (Google OAuth Callback)
authRouter.get("/google/callback", passport.authenticate("google", { session: false, failureRedirect: '/login/failed' }), googleCallback );

// POST /v1/auth/verify-email
// Add validation middleware: validateVerifyEmail
authRouter.post("/verify-email", verifyEmail);

// POST /v1/auth/resend-verification-email
// Add validation middleware: validateResendVerification
// Add rate limiting middleware
authRouter.post("/resend-verification-email", resendVerificationEmail);

// POST /v1/auth/forgot-password
// Add validation middleware: validateForgotPassword
// Add rate limiting middleware
authRouter.post("/forgot-password", forgotPassword);

// POST /v1/auth/reset-password/:token
// Add validation middleware: validateResetPassword
authRouter.post("/reset-password/:token", resetPassword);

// --- Private Routes (Require Authentication) ---

// GET /v1/auth/check-auth (Verify token and return user)
authRouter.get('/check-auth', authorize, checkAuth);

// --- Admin Routes (Moved to admin.routes.js) ---
// authRouter.post("/banned/:id", authorize, authorizeAdmin, bannedUser);
// authRouter.post("/unbanned/:id", authorize, authorizeAdmin, unbannedUser); // Combined into bannedUser toggle

export default authRouter;

