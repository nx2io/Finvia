import { Router } from 'express';

// Import controllers
import {
    getWalletDetails,
    createSubWallet,
    updateSubWallet,
    deleteSubWallet,
    transferInternal
} from '../controllers/wallet.controller.js';

// Import middleware
import { authorize } from '../middlewares/auth.middleware.js'; // General authorization
// import { validateCreateSubWallet, validateTransferInternal, ... } from '../middlewares/validation.middleware.js'; // Placeholder for validation

const walletRouter = Router();

// All routes require authentication
walletRouter.use(authorize);

// GET /v1/wallet/details
walletRouter.get('/details', getWalletDetails);

// --- Sub-Wallet Management ---

// POST /v1/wallet/subwallets
// Add validation middleware: validateCreateSubWallet
walletRouter.post('/subwallets', createSubWallet);

// PUT /v1/wallet/subwallets/:subWalletId
// Add validation middleware: validateUpdateSubWallet
walletRouter.put('/subwallets/:subWalletId', updateSubWallet);

// DELETE /v1/wallet/subwallets/:subWalletId
walletRouter.delete('/subwallets/:subWalletId', deleteSubWallet);

// --- Internal Transfers ---

// POST /v1/wallet/transfer-internal
// Add validation middleware: validateTransferInternal
walletRouter.post('/transfer-internal', transferInternal);

export default walletRouter;

