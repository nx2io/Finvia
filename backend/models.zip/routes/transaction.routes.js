import { Router } from 'express';

// Import controllers
import {
    getTransactionHistory,
    getTransactionDetails,
    sendP2PTransfer,
    requestFunds,
    listReceivedFundRequests,
    listSentFundRequests,
    respondToFundRequest,
    cancelFundRequest,
    fulfillFundRequest,
    initiateWithdrawal
} from '../controllers/transaction.controller.js';

// Import middleware
import { authorize } from '../middlewares/auth.middleware.js'; // General authorization
// import { validateP2PTransfer, validateFundRequest, ... } from '../middlewares/validation.middleware.js'; // Placeholder for validation

const transactionRouter = Router();

// All routes require authentication
transactionRouter.use(authorize);

// --- Transaction History ---
// GET /v1/transactions?limit=10&page=1&type=P2P_SEND&status=completed
transactionRouter.get('/', getTransactionHistory);

// GET /v1/transactions/:transactionId
transactionRouter.get('/:transactionId', getTransactionDetails);

// --- P2P Transfers ---
// POST /v1/transactions/p2p-transfer
// Add validation middleware: validateP2PTransfer
transactionRouter.post('/p2p-transfer', sendP2PTransfer);

// --- Fund Requests ---
// POST /v1/transactions/fund-request/request
// Add validation middleware: validateFundRequest
transactionRouter.post('/fund-request/request', requestFunds);

// GET /v1/transactions/fund-request/received
transactionRouter.get('/fund-request/received', listReceivedFundRequests);

// GET /v1/transactions/fund-request/sent
transactionRouter.get('/fund-request/sent', listSentFundRequests);

// PUT /v1/transactions/fund-request/:requestId/respond
// Add validation middleware: validateRespondFundRequest
transactionRouter.put('/fund-request/:requestId/respond', respondToFundRequest);

// PUT /v1/transactions/fund-request/:requestId/cancel
transactionRouter.put('/fund-request/:requestId/cancel', cancelFundRequest);

// POST /v1/transactions/fund-request/:requestId/fulfill
transactionRouter.post('/fund-request/:requestId/fulfill', fulfillFundRequest);

// --- Withdrawals ---
// POST /v1/transactions/withdraw
// Add validation middleware: validateWithdrawal
transactionRouter.post('/withdraw', initiateWithdrawal);

export default transactionRouter;

